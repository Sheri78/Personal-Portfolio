<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    include("db_connection.php");

    // Retrieve form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Check if the username is already taken
    $check_query = "SELECT * FROM info WHERE username = '$username'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        // Username already exists, display an error message
        echo "Username already taken. Please choose a different one.";
    } else {
        // Insert new user into the database
        $insert_query = "INSERT INTO info (username, password) VALUES ('$username', '$password')";
        $insert_result = mysqli_query($conn, $insert_query);

        if ($insert_result) {
            // Signup successful, redirect to login page
            header("Location: index.php");
            exit();
        } else {
            // Signup failed, display an error message
            echo "Signup failed. Please try again.";
        }
    }

    // Close database connection
    // ... existing code ...

// Check if a PDF file is uploaded
if (isset($_FILES['cv_pdf']) && $_FILES['cv_pdf']['error'] == UPLOAD_ERR_OK) {
    // Read the PDF file content
    $pdf_content = file_get_contents($_FILES['cv_pdf']['tmp_name']);

    // Update the database query to include the PDF content
    $insert_query = "INSERT INTO info (username, password, cv_pdf) VALUES ('$username', '$password', '$pdf_content')";
    $insert_result = mysqli_query($conn, $insert_query);

    // ... rest of the code ...
}

// ... existing code ...

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Signup - Shahryar's Portfolio</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <h2 class="text-center mb-4">Signup</h2>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Signup</button>
                </form>
                <div class="text-center mt-3">
                    <p>Already have an account? <a href="login.php">Login</a></p>
                </div>
            </div>
        </div>
    </div>
  
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
