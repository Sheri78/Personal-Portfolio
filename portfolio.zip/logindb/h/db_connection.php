<?php
// Database configuration
$server = "localhost";
$username = "root"; // default username for XAMPP
$password = ""; // default password for XAMPP
$database = "logindatabase";

// Create connection
$conn = mysqli_connect($server, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
