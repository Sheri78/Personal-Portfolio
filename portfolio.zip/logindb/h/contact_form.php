<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    include("db_connection.php");

    // Sanitize and validate the input data
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $subject = mysqli_real_escape_string($conn, $_POST["subject"]);
    $message = mysqli_real_escape_string($conn, $_POST["message"]);

    // Insert form submission into the database
    $insert_query = "INSERT INTO contact_messages (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
    $insert_result = mysqli_query($conn, $insert_query);

    // Check if the insertion was successful
    if ($insert_result) {
        echo json_encode(array('status' => 'success'));
    } else {
        echo json_encode(array('status' => 'error', 'message' => 'Error submitting form. Please try again.'));
    }

    // Close database connection
    mysqli_close($conn);
} else {
    echo "Invalid request method.";
}
?>
