<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    include("db_connection.php");

    // Retrieve form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // SQL query to check if the provided credentials are valid
    $query = "SELECT * FROM info WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Valid credentials, redirect to the next page
        header("Location: 2nd.html");
        exit();
    } else {
        // Invalid credentials, display an error message
        echo "Invalid username or password.";
    }

    // Close database connection
    mysqli_close($conn);
}
?>
