<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Details</title>
    
    <style>
    body {
        font-family: 'Arial', sans-serif;
        margin: 20px;
        background-color: #f8f8f8; /* Set a light background color */
    }

    h1 {
        color: #333;
        text-align: center; /* Center the heading */
        margin-bottom: 20px; /* Add some space below the heading */
    }

    p {
        color: #666;
        line-height: 1.6; /* Improve readability with slightly increased line height */
    
    }

    img {
    max-width: 100%;
    height: auto;
    
    margin: 0 auto;
    display: block;
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(110, 110, 110, 100);
    margin-bottom: 100px;
    object-fit: cover; /* Ensure the image covers the entire container */
}

</style>

</head>
<body>
<?php
// project_details.php

// Include database connection file
include("db_connection.php");

// Get project ID from the URL
$projectId = $_GET['id'];

// Fetch project details from the database
$query = "SELECT * FROM projects WHERE id = $projectId";
$result = mysqli_query($conn, $query);

if ($result) {
    $project = mysqli_fetch_assoc($result);

    // Display project details (you can customize this part)
    echo "<h1>{$project['title']}</h1>";
    echo "<p>{$project['description']}</p>";

    // Display image 1
    if (!empty($project['image1'])) {
        $image1Encoded = base64_encode($project['image1']);
        echo "<img src='data:image/jpeg;base64,{$image1Encoded}' alt='Image 1'>";
    }
    // Display image 2 if it exists
    if (!empty($project['image2'])) {
        $image2Encoded = base64_encode($project['image2']);
        echo "<img src='data:image/jpeg;base64,{$image2Encoded}' alt='Image 2'>";
    }

    echo "<p>{$project['details']}</p>";
} else {
    echo "Error fetching project details.";
}

// Close database connection
mysqli_close($conn);
?>

</body>
</html>
