// download_cv.php
<?php
include("db_connection.php");

$username = "pdf2"; // Replace with the actual username for which you want to fetch the CV

$query = "SELECT cv_pdf FROM info WHERE username = '$username'";
$result = mysqli_query($conn, $query);

if ($row = mysqli_fetch_assoc($result)) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="cv.pdf"');
    echo $row['cv_pdf'];
} else {
    echo "CV not found.";
}

mysqli_close($conn);
?>
