function loadProjectDetails(projectId) {
    var xhr = new XMLHttpRequest();

    // Assuming you have a server script to fetch project details
    xhr.open('GET', 'get_project_details.php?id=' + projectId, true);

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById('project-details-container').innerHTML = xhr.responseText;
        }
    };

    xhr.send();
}

// Updated function to get project ID from the clicked element
document.addEventListener('DOMContentLoaded', function () {
    var projectThumbnails = document.querySelectorAll('.portfolio-item');

    projectThumbnails.forEach(function (thumbnail) {
        thumbnail.addEventListener('click', function () {
            var projectId = this.getAttribute('data-project-id');
            loadProjectDetails(projectId);
        });
    });
});
